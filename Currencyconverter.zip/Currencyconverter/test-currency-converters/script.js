import {convertcurrency} from "cs-currency-converters";


convertcurrency("USD","INR",5).then(res=>console.log(res));